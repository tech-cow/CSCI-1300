counter = 0
while counter < 20 :
	counter += 1
	#print(counter)
while True:
	print(counter)