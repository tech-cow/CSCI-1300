height = input("Enter 141ft or not: ")
#x = true

x = "small" if int(height) == 141 else "not small"
print(x)